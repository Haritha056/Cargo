<?php

include('db.php');

$name = mysqli_escape_string($conn, $_POST['name']);
$email = mysqli_escape_string($conn, $_POST['email']);
$subject = mysqli_escape_string($conn, $_POST['subject']);
$number = mysqli_escape_string($conn, $_POST['number']);
$message = mysqli_escape_string($conn, $_POST['message']);
mysqli_query($conn, "INSERT INTO `contact_details`(`name`, `email`, `subject`, `phone_no`, `message`) VALUES ('$name','$email', '$subject', '$number', '$message')");

echo 'Success';

?>