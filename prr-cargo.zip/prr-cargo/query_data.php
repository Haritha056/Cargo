<?php

include('db.php');

$name = mysqli_escape_string($conn, $_POST['name']);
$vehicle = mysqli_escape_string($conn, $_POST['vehicle']);
$message = mysqli_escape_string($conn, $_POST['message']);

$created_by = 1;

mysqli_query($conn, "INSERT INTO `query_on_vehicle`(`name`,`vehicle`,`message`) VALUES ('$name', '$vehicle', '$message')");

echo 'Success';

?>